﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR15_16
{
    class Program
    {
        static void Main(string[] args)
        {
            PRICE anketa = new PRICE(); //объект класса
            anketa.TNAME = "Пицца ";
            anketa.Cost = 50;

            Console.WriteLine(anketa.PrintInfo());

            PRICE anketa1 = new PRICE("Магнит ",
                 1000, "Шаурма", 100);

            Console.WriteLine(anketa1.PrintInfo());

            //создание массива объектов
            Console.WriteLine("Введите количество магазинов N=");
            int N = int.Parse(Console.ReadLine());

            PRICE[] anketas = new PRICE[N];
            for (int i = 0; i < N; i++)
            {
                anketas[i] = new PRICE();
                Console.WriteLine("Введите название товара: ");
                anketas[i].TNAME = Console.ReadLine();
                Console.WriteLine("Введите цену товара: ");
                anketas[i].Cost = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите название магазина: ");
                anketas[i].MNAME = Console.ReadLine();
                Console.WriteLine("Введите количество товара: ");
                anketas[i].KOLVO = int.Parse(Console.ReadLine());


            }
            foreach (PRICE cls in anketas)
            {
                Console.WriteLine(cls.PrintInfo());
            }
            Console.ReadKey();
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarodubcevPR15_16
{
    class STUDENT
    {
        //поля класса
        private string FIO;
        private int Nombergroup;
        private string YS;
        // свойства для доступа к полям
        public string TFIO
        {
            get { return FIO; }
            set { FIO = value; }
        }
        public int TNombergroup
        {
            get { return Nombergroup; }
            set { Nombergroup = value; }
        }
        public string TYS
        {
            get { return YS; }
            set { YS = value; }
        }
        //методы 
        //конструктор без параметров
        public STUDENT()
        {
            FIO = "Петров Артём Николаеевич";
            Nombergroup = 4;
            YS = "Математика = 5, Русский язык = 4, Английский язык = 3, Биология = 5, Литература = 4";


        }
        //конструктор с параметрами
        public STUDENT(string f,
            int n, string y)
        {
            FIO = f;
            Nombergroup = n;
            YS = y;

        }
        //вывод информации об объекте
        public string PrintInfo()
        {
            return $" Фамилия и инициалы {FIO} " +
                $"Группа: {Nombergroup} " +
                $" Успеваемость по предметам: {YS} " ;
        }
    }
}

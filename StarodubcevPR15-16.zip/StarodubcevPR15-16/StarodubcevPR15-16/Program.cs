﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarodubcevPR15_16
{
    class Program
    {
        static void Main(string[] args)
        {
            STUDENT anketa = new STUDENT(); //объект класса
            anketa.TFIO = "Иванов Иван Иванович ";
            anketa.TNombergroup = 5;

            Console.WriteLine(anketa.PrintInfo());

            STUDENT anketa1 = new STUDENT("Редьков  Егор Петрович ",
                 1, "Математика = 3, Русский язык = 4, Английский язык = 5, Биология = 5, Литература = 4");

            Console.WriteLine(anketa1.PrintInfo());

            //создание массива объектов
            Console.WriteLine("Введите количество магазинов N=");
            int N = int.Parse(Console.ReadLine());

            STUDENT[] anketas = new STUDENT[N];
            for (int i = 0; i < N; i++)
            {
                anketas[i] = new STUDENT();
                Console.WriteLine("Введите фамилию и инициалы: ");
                anketas[i].TFIO = Console.ReadLine();
                Console.WriteLine("Введите номер группы: ");
                anketas[i].TNombergroup = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите Успеваемость по предметам: ");
                anketas[i].TYS = Console.ReadLine();


            }
            foreach (STUDENT cls in anketas)
            {
                Console.WriteLine(cls.PrintInfo());
            }
            Console.ReadKey();
        }
    }
}
